
"use strict";

let jointMessage = require('./jointMessage.js');
let location = require('./location.js');

module.exports = {
  jointMessage: jointMessage,
  location: location,
};
