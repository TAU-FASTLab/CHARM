# Deprecated Features

Currently no deprecated Features in Firos.
