# Deinstalling FIROS

To remove FIROS from your computer you just need to remove the local repository. Also remove the Configuration-Folder
you might have created throughout the usage of FIROS.

## Removing from Docker

To remove FIROS from Docker you can just execute:

```shell
docker rmi firos:localbuild
```

or

```shell
docker rmi firos:latest
```
