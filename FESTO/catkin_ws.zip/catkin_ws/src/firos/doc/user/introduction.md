# Introduction

Welcome to Module's User & Programmers Guide!

Any feedback on this document is highly welcome, including bug reports, typos or stuff you think should be included but
is not. Please send the feedback through email or create a Issue [here](https://github.com/iml130/firos/issues). Thanks
in advance!
